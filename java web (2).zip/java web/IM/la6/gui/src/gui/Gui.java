package gui;

import my.gui.NewJFrame;

public class Gui {
    public static void main(String[] args) {
        NewJFrame f=new NewJFrame();
        f.show();
             
        
    }
    
}
