package com.mycompany.exercise03;
public class Exercise03 
{

    public static void main(String[] args) 
    {
       Student s1 = new Student();
       s1.display();
    }
}
