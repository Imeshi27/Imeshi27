package com.mycompany.exercise03;
public class Student 
{
    final int marks=100;
    final void display();
    // The 'final' keyword is used to restrict the modification of a class, method, or variable.
    //In the code 'Student' class is declared as 'final', which means it cannot be inherited by any other class.
}
