package practical05q2;
public class Practical05Q2 {
public static void main(String[] args) 
{
    
    }
    
}
